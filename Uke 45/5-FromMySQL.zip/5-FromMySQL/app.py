from flask import Flask, render_template
import mysql.connector

app = Flask(__name__)


@app.route('/')
def show_person_data_mysql():
    byer = []
    column_name = []
    try:
        query = "SELECT * FROM world.city;"

        query_2 = f"""
                SELECT COLUMN_NAME
                FROM INFORMATION_SCHEMA.COLUMNS
                WHERE TABLE_SCHEMA = 'world'
                AND TABLE_NAME = 'city';
"""

        with mysql.connector.connect(host="localhost", port=3306,
                                     user="root", password="gokstad2023",
                                     database="world") as conn:

            # steg 2.
            with conn.cursor() as db_cursor:
                db_cursor.execute(query)
                results = db_cursor.fetchall()
                for result in results:
                    byer.append(result)
            with conn.cursor(dictionary=True) as db_cursor:
                db_cursor.execute(query_2)
                column_name = db_cursor.fetchall()

    except mysql.connector.DatabaseError as dbErr:
        print(f"database error: {dbErr}")

    return render_template('world.html', byer=byer, column_name=column_name)


if __name__ == '__main__':
    app.run(debug=True, port=5000)
